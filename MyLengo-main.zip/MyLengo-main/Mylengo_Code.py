import os
import six
import ffmpeg
from gtts import gTTS
import moviepy.editor as mp
from pydub import AudioSegment
import speech_recognition as sr
from google.cloud import storage
from collections import OrderedDict
from google.cloud import translate_v2
from pydub.silence import split_on_silence
from google.cloud import translate_v2 as translate


## Convert mp4 to wav File

## Insert Local Video File Path 
clip = mp.VideoFileClip(r"C:/Users/ghosh/A_Neural_Machine_Language_Translation/inputfolder/arabic.mp4")
  
## Insert Local Audio File Path
clip.audio.write_audiofile(r"C:/Users/ghosh/A_Neural_Machine_Language_Translation/audio/arabic.wav")

filename = "C:/Users/ghosh/A_Neural_Machine_Language_Translation/audio/arabic.wav"

## Create a speech recognition object
r = sr.Recognizer()

## A function that splits the audio file into chunks and applies speech recognition

def get_large_audio_transcription(path):
    sound = AudioSegment.from_wav(path)  
    chunks = split_on_silence(sound,
        min_silence_len = 500,
        silence_thresh = sound.dBFS-14,
        keep_silence=500,
    )
    folder_name = "audio-chunks"
    # create a directory to store the audio chunks
    if not os.path.isdir(folder_name):
        os.mkdir(folder_name)
    whole_text = ""
    # process each chunk 
    for i, audio_chunk in enumerate(chunks, start=1):
        chunk_filename = os.path.join(folder_name, f"chunk{i}.wav")
        audio_chunk.export(chunk_filename, format="wav")
        with sr.AudioFile(chunk_filename) as source:
            audio_listened = r.record(source)
            try:
                text = r.recognize_google(audio_listened, language = "ar-SA")
            except sr.UnknownValueError as e:
                print("Error:", str(e))
            else:
                text = f"{text.capitalize()}. "
                print(chunk_filename, ":", text)
                whole_text += text
    # return the text for all chunks detected
    return whole_text

v = get_large_audio_transcription(filename)


## Write-overwrites

file1 = open("C:/Users/ghosh/A_Neural_Machine_Language_Translation/output/arabic.txt","w", encoding="utf-8")#write mode
file1.write(v)
file1.close()


## Reading file

f = open("C:/Users/ghosh/A_Neural_Machine_Language_Translation/output/arabic.txt","r", encoding="utf-8")
contents = f.read()
chunks = contents.split('.')
b = list(OrderedDict.fromkeys(chunks))


##  Cloud translation google API setup

os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="C:/Users/ghosh/A_Neural_Machine_Language_Translation/mylengo-680079b52fc1.json"

def implicit():
    # If you don't specify credentials when constructing the client, the
    # client library will look for credentials in the environment.
    storage_client = storage.Client.from_service_account_json('mylengo-680079b52fc1.json')

    # Make an authenticated API request
    buckets = list(storage_client.list_buckets())
    print(buckets)

## Translation

translate_client = translate.Client()

if isinstance(b, six.binary_type):
    b = b.decode("utf-8")

# Text can also be a sequence of strings, in which case this method
# will return a sequence of results for each text.
result = translate_client.translate(b, target_language="en", model="nmt")

#print(u"Text: {}".format(result["input"]))
#print(u"Translation: {}".format(result["translatedText"]))
#print(u"Detected source language: {}".format(result["detectedSourceLanguage"]))
    
for i in b:
    v1 = result["translatedText"]
v1

## Text to wav format

text_file = open("C:/Users/ghosh/A_Neural_Machine_Language_Translation/output/arabic.txt","r", encoding='utf-8')
lines1 = text_file.read().replace("\n","_")
chunks = lines1.split('_')
b = list(OrderedDict.fromkeys(chunks))

def listToString(s):
    str1 = " "
    return (str1.join(s))

final = listToString(b)
tts = gTTS(text=final, lang = "en", slow=False).save("C:/Users/ghosh/A_Neural_Machine_Language_Translation/output/arabic1.wav")


## Convert audio to video

def convert_audio_to_video(video_input, out_audio):
    input_video = ffmpeg.input(video_input)
    input_audio = ffmpeg.input(out_audio)
    print(out_audio, "output audio*****")
    out_video_path = out_audio[:-4]+"_out.mp4"
    ffmpeg.concat(input_video, input_audio, v=1, a=1).output(out_video_path).run()
    return out_video_path

convert_audio_to_video("C:/Users/ghosh/A_Neural_Machine_Language_Translation/inputfolder/arabic.mp4","C:/Users/ghosh/A_Neural_Machine_Language_Translation/output/arabic1.wav")

